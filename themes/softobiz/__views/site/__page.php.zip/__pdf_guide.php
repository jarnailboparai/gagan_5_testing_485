<div class="row">
	<div class="span11">
		<div class="btn-group centered">
			<a class="btn btn-large" href="<?php echo $this->createUrl('site/training'); ?>">Training Home</a>
			<a class="btn btn-large" href="<?php echo $this->createUrl('site/videotraining'); ?>">Video Training</a>
			<a class="btn btn-large active" href="<?php echo $this->createUrl('site/pdfguide'); ?>">PDF Training Guides</a>
			<a class="btn btn-large" href="<?php echo $this->createUrl('site/contracts'); ?>">Sample Contracts</a>
		</div>
	</div>
</div>