 $(document).ready(function() {
      $('#back-link').click(function() {
         history.go(-1) 
       });
   });